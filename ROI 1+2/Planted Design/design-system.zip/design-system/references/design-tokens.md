# Design Tokens

Complete catalog of all design tokens. This is the source of truth for the Tailwind config.

## Color Palette

### Brand Colors

| Token | Hex | Usage |
|-------|-----|-------|
| `primary` | `#DAC4FF` | Primary brand (lilac), buttons, focus rings |
| `secondary` | `#B4FA64` | Secondary brand (lime), accent highlights |
| `tertiary` | `#F4F0ED` | Tertiary, subtle backgrounds |

### Base Colors

| Token | Hex |
|-------|-----|
| `black` | `#000000` |
| `white` | `#ffffff` |
| `offWhite` | `#EBEBEB` |
| `transparent` | transparent |
| `current` | currentColor |
| `inherit` | inherit |

### Dark Green (Primary Text & Dark Buttons)

| Token | Hex |
|-------|-----|
| `darkgreen-100` | `#002616` |
| `darkgreen-75` | `#405C50` |
| `darkgreen-50` | `#80928A` |
| `darkgreen-25` | `#BFC9C5` |
| `darkgreen-10` | `#E5E9E8` |

### Anthracite (Body Text & Secondary Text)

| Token | Hex |
|-------|-----|
| `an-100` | `#232D32` |
| `an-90` | `#3C4245` |
| `an-80` | `#4F575B` |
| `an-60` | `#7B8184` |
| `an-40` | `#A7ABAD` |
| `an-20` | `#D3D5D8` |
| `an-10` | `#E9EAEA` |

### Interface Grays (Borders, Backgrounds, Disabled)

| Token | Hex |
|-------|-----|
| `sfgray-100` | `#8E93A5` |
| `sfgray-80` | `#A5A9B7` |
| `sfgray-60` | `#BBBEC9` |
| `sfgray-40` | `#D2D4DB` |
| `sfgray-20` | `#E8E9ED` |
| `sfgray-10` | `#F4F4F6` |
| `sfgray-5` | `#F9F9F9` |

### Legacy Grays

| Token | Hex |
|-------|-----|
| `gray-20` | `#E4E4E4` |
| `gray-10` | `#EBEBEB` |
| `gray-5` | `#F9F9F9` |

### Semantic: Success

| Token | Hex | Usage |
|-------|-----|-------|
| `succ-100` | `#008C6F` | Success text |
| `succ-80` | `#00C39A` | Success icons, borders |
| `succ-70` | `#98E1A2` | Success accents |
| `succ-60` | `#E5F9F4` | Success backgrounds |

### Semantic: Warning

| Token | Hex | Usage |
|-------|-----|-------|
| `warn-100` | `#DE9906` | Warning text |
| `warn-80` | `#FFB822` | Warning icons, borders |
| `warn-60` | `#FFF7E8` | Warning backgrounds |

### Semantic: Danger

| Token | Hex | Usage |
|-------|-----|-------|
| `dang-100` | `#9E0038` | Danger text |
| `dang-80` | `#F4516C` | Danger icons, borders, error text |
| `dang-60` | `#FDEDF0` | Danger backgrounds |

### Feature: Blue

| Token | Hex |
|-------|-----|
| `sfblue-100` | `#4A6FE3` |
| `sfblue-80` | `#6E8CE9` |
| `sfblue-60` | `#92A9EE` |
| `sfblue-40` | `#B7C5F4` |
| `sfblue-20` | `#DBE2F0` |
| `sfblue-10` | `#EDF1FC` |

### Feature: Orange

| Token | Hex |
|-------|-----|
| `sforange-100` | `#FD9073` |
| `sforange-80` | `#FEA68F` |
| `sforange-60` | `#FEBCAB` |
| `sforange-40` | `#FED3C7` |
| `sforange-20` | `#FFE9E3` |
| `sforange-10` | `#FFF4F1` |
| `sforange-5` | `#fef3f1` |

### Feature: Green

| Token | Hex |
|-------|-----|
| `sfgreen-100` | `#5FAF9A` |
| `sfgreen-80` | `#7FBFAE` |
| `sfgreen-60` | `#9FCFC2` |
| `sfgreen-40` | `#BFDFD7` |
| `sfgreen-20` | `#DFEFEB` |
| `sfgreen-10` | `#EFF7F5` |

### Feature: Purple

| Token | Hex |
|-------|-----|
| `sfpurple-100` | `#B89DE7` |
| `sfpurple-80` | `#C5AEE9` |
| `sfpurple-60` | `#D2C0EC` |
| `sfpurple-40` | `#DFD2ED` |
| `sfpurple-20` | `#EBE3F0` |
| `sfpurple-10` | `#F8F5FD` |

### Accent: Pink

| Token | Hex |
|-------|-----|
| `pink-100` | `#F195FF` |
| `pink-80` | `#F4AAFF` |
| `pink-60` | `#F7BFFF` |
| `pink-40` | `#F9D5FF` |
| `pink-20` | `#FCEAFF` |
| `pink-10` | `#FEF4FF` |

### Accent: Lime

| Token | Hex |
|-------|-----|
| `lime-100` | `#B4FA64` |
| `lime-80` | `#C3FB83` |
| `lime-60` | `#D2FCA2` |
| `lime-40` | `#E1FDC1` |
| `lime-20` | `#F0FEE0` |
| `lime-10` | `#F8FFEF` |

### Accent: Lilac (2025 Rebrand)

| Token | Hex |
|-------|-----|
| `lilac-100` | `#DAC4FF` |
| `lilac-80` | `#EBDBFE` |
| `lilac-60` | `#E9DCFF` |
| `lilac-40` | `#F0E7FF` |
| `lilac-20` | `#F8F3FF` |
| `lilac-10` | `#FBF9FF` |

### Accent: Morning Sun

| Token | Hex |
|-------|-----|
| `morningsun-100` | `#FEF8BD` |
| `morningsun-40` | `#FFFCE5` |

### Accent: Coral

| Token | Hex |
|-------|-----|
| `coral-100` | `#FFAF94` |
| `coral-10` | `#FFF7F4` |

### Accent: Blue (non-feature)

| Token | Hex |
|-------|-----|
| `blue-100` | `#5D47FF` |
| `blue-10` | `#EFEDFF` |

### Accent: Cool Gray

| Token | Hex |
|-------|-----|
| `coolgray-60` | `#757988` |
| `coolgray-10` | `#DFE3F2` |

### Legacy Green/Soft Green/Red

| Token | Hex |
|-------|-----|
| `green-100` | `#7CCD87` |
| `green-10` | `#F2FAF3` |
| `softGreen-100` | `#5FAF9A` |
| `softGreen-60` | `#9FCFC2` |
| `softGreen-10` | `#EFF7F5` |
| `red-100` | `#F4516C` |
| `red-10` | `#FEEEF0` |

## Typography

### Font Family

```js
fontFamily: {
  sans: ['Saans', 'sans-serif'],
  serif: ['Saans', 'serif'],
}
```

### Font Weights

| Tailwind class | Weight value | Font file |
|---------------|-------------|-----------|
| `font-normal` | 380 | SaansRegular.otf |
| `font-medium` | 500 | SaansMedium.otf |
| `font-semibold` | 670 | SaansSemiBold.otf |
| `font-bold` | 790 | SaansBold.otf |

Each weight also has an italic variant (e.g., SaansRegularItalic.otf).

### Font Size Scale

| Tailwind class | Size | Line height |
|---------------|------|-------------|
| `text-xs` | 10px | 16px |
| `text-sm` | 12px | 18px |
| `text-md` | 14px | 22px |
| `text-lg` | 16px | 24px |
| `text-xl` | 20px | 28px |
| `text-2xl` | 22px | 32px |
| `text-3xl` | 26px | 32px |
| `text-4xl` | 32px | 36px |
| `text-5xl` | 36px | 48px |
| `text-6xl` | 48px | 1 (unitless) |
| `text-7xl` | 56px | 1 |
| `text-8xl` | 64px | 1 |

## Border Radius

| Tailwind class | Value |
|---------------|-------|
| `rounded-none` | 0 |
| `rounded-sm` | 4px |
| `rounded` (DEFAULT) | 6px |
| `rounded-md` | 10px |
| `rounded-lg` | 30px |
| `rounded-full` | 9999px |

## Box Shadows

| Tailwind class | Value | Usage |
|---------------|-------|-------|
| `shadow-lg` | `0 10px 15px -3px rgb(0 0 0 / 0.03), 0 4px 6px -4px rgb(0 0 0 / 0.03)` | Card hover |
| `shadow-xl` | `0 20px 25px -5px rgb(0 0 0 / 0.03), 0 8px 10px -6px rgb(0 0 0 / 0.03)` | Popovers, dropdowns, tooltips |

## Breakpoints

| Tailwind prefix | Width |
|----------------|-------|
| `sm` | 640px |
| `md` | 768px |
| `lg` | 1024px |
| `xl` | 1280px |
| `2xl` | 1536px |
| `3xl` | 1650px (custom) |

Container: centered, 32px padding, maxes out at screen widths.

## Animation Keyframes

### Slide & Fade (for Radix popover/tooltip transitions)

```js
slideDownAndFade: {
  from: { opacity: 0, transform: 'translateY(-2px)' },
  to: { opacity: 1, transform: 'translateY(0)' },
}
slideUpAndFade: {
  from: { opacity: 0, transform: 'translateY(2px)' },
  to: { opacity: 1, transform: 'translateY(0)' },
}
slideLeftAndFade: {
  from: { opacity: 0, transform: 'translateX(2px)' },
  to: { opacity: 1, transform: 'translateX(0)' },
}
slideRightAndFade: {
  from: { opacity: 0, transform: 'translateX(-2px)' },
  to: { opacity: 1, transform: 'translateX(0)' },
}
```
Animation: `400ms cubic-bezier(0.16, 1, 0.3, 1)`

### Accordion (Radix content height)

```js
fadeDown: {
  '0%': { height: 0, opacity: 0 },
  '100%': { height: 'var(--radix-accordion-content-height)', opacity: 1 },
}
fadeUp: {
  '0%': { height: 'var(--radix-accordion-content-height)', opacity: 1 },
  '100%': { height: 0, opacity: 0 },
}
```

### Spinner

```js
spinner: {
  '0%': { transform: 'rotate(0deg)' },
  '100%': { transform: 'rotate(360deg)' },
}
```
Animation: `1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite`

### AI Gradient

```js
'ai-gradient': {
  '0%': { backgroundPosition: '0% 50%' },
  '50%': { backgroundPosition: '100% 50%' },
  '100%': { backgroundPosition: '0% 50%' },
}
```
Animation: `2s ease infinite`

### Sway-X (loading bar)

```js
'sway-x': {
  '0%, 100%': { transform: 'translateX(-85%)' },
  '50%': { transform: 'translateX(85%)' },
}
```
Animation: `1.2s cubic-bezier(0.59, 1, 0.86, 1) infinite`

### Shake

```js
shake: {
  '0%, 100%': { transform: 'rotate(0deg)' },
  '25%': { transform: 'rotate(10deg)' },
  '75%': { transform: 'rotate(-10deg)' },
}
```
Animation: `0.4s ease-in-out`

## Custom Tailwind Variants

```js
// disabled: matches both native :disabled and aria-disabled="true"
addVariant('disabled', '&:is(:disabled, [aria-disabled="true"])');

// invalid: matches both native :invalid and aria-invalid="true"
addVariant('invalid', '&:is(:invalid, [aria-invalid="true"])');

// only-child
addVariant('only-child', '&:only-child');
```

## CSS Variable Export Pattern

All colors are exported as CSS variables on `:root` via a Tailwind plugin. The variable naming pattern is `--tw-color-{group}-{shade}`:

```js
plugin(function ({ addBase, theme }) {
  function extractColorVars(colorObj, colorGroup = '') {
    return Object.keys(colorObj).reduce((vars, colorKey) => {
      const value = colorObj[colorKey];
      const cssVariable = colorKey === 'DEFAULT'
        ? `--tw-color${colorGroup}`
        : `--tw-color${colorGroup}-${colorKey}`;
      const newVars = typeof value === 'string'
        ? { [cssVariable]: value }
        : extractColorVars(value, `-${colorKey}`);
      return { ...vars, ...newVars };
    }, {});
  }

  addBase({
    ':root': extractColorVars(theme('colors')),
    body: { color: 'var(--tw-color-an-100)' },
  });
});
```

Examples: `var(--tw-color-primary)` → `#DAC4FF`, `var(--tw-color-sfblue-100)` → `#4A6FE3`

## Background Gradients

| Tailwind class | Definition |
|---------------|-----------|
| `bg-gradientMorningsun` | `linear-gradient(90deg, gray-10, morningsun-100)` |
| `bg-gradientLilac` | `linear-gradient(90deg, gray-10, lilac-100)` |
| `bg-dividerDashedH` | Horizontal dashed divider (75% sfgray-40) |
| `bg-dividerDashedV` | Vertical dashed divider (75% sfgray-40) |

## Backdrop Blur

| Tailwind class | Value |
|---------------|-------|
| `backdrop-blur-sm` | 2.5px |

## Custom Utility

```css
.border-dashed-lg {
  border-style: dashed;
  background-image: url("data:image/svg+xml,..."); /* rounded dashed border via SVG */
  border: none;
}
```
