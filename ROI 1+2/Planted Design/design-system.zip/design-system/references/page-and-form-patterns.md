# Page & Form Patterns

Layouts, page structure, form handling, and composition patterns.

## Page Composition

Standard page hierarchy: `Page > PageHeader > PageContent > Card`

### Page

Top-level wrapper for any page:
```tsx
const Page = forwardRef<HTMLDivElement, ComponentPropsWithoutRef<'div'>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={classNames('flex flex-col gap-4 pb-8', className)} {...props} />
  ),
);
```

### PageHeader

Sticky header with left/right slot composition:

```tsx
// Container: sticky top-0 z-20 flex items-start justify-between gap-4 bg-sfgray-5 px-8 py-4
// Left slot (PageHeaderLeft): flex w-full flex-col gap-3 overflow-hidden
//   - Account selector (if applicable)
//   - Title + breadcrumbs
// Right slot (PageHeaderActions): flex items-center gap-6
//   - Action buttons separated by vertical dividers (h-8 w-px bg-sfgray-40)
```

Usage pattern with slot components:
```tsx
<Page>
  <PageHeader>
    <PageHeaderLeft>
      <PageTitle>Dashboard</PageTitle>
    </PageHeaderLeft>
    <PageHeaderActions>
      <Button>Export</Button>
      <Button variant="primary">Create New</Button>
    </PageHeaderActions>
  </PageHeader>
  <PageContent>
    <Card>...</Card>
  </PageContent>
</Page>
```

### PageTitle

```tsx
// h1 with text-xl font-bold
<h1 className="text-xl font-bold" />
```

### PageContent

```tsx
// <main> element with horizontal padding
<main className={classNames('relative px-8', className)} />
```

## Detail Page Layout

Two-column layout for detail/edit pages. Main content (2/3) + metadata sidebar (1/3) with a vertical divider between them.

```tsx
// Detail: flex w-full flex-row gap-12 max-[1400px]:flex-wrap-reverse
// DetailMain: order-1 w-full min-w-0 flex-grow
// DetailDivider: order-2 shrink-0 max-[1400px]:hidden (vertical line)
// DetailMeta: order-3 w-1/3 shrink-0 max-[1400px]:w-full (sticky below header)
```

Usage:
```tsx
<Detail>
  <DetailMain>
    {/* Main form / content */}
  </DetailMain>
  <DetailDivider />
  <DetailMeta>
    {/* Metadata, status, dates, related info */}
  </DetailMeta>
</Detail>
```

At viewport widths below 1400px, the layout wraps in reverse order (meta appears above main).

## Authenticated Layout

CSS Grid layout for the entire authenticated application:

```tsx
<div className="grid min-h-screen min-w-[900px] grid-cols-[min-content_1fr_min-content] bg-offwhite [grid-template-areas:'sidebar_main'] dark:bg-an-100">
  <MainMenu />
  <div className="flex w-full min-w-0 flex-col [grid-area:main]">
    <Suspense fallback={<Loading />}>
      <Outlet />
    </Suspense>
  </div>
</div>
```

Key properties:
- `min-w-[900px]` — desktop-only, no mobile support
- `bg-offwhite` (#EBEBEB) — page background
- `dark:bg-an-100` — dark mode background
- Sidebar is `min-content` width
- Main content fills remaining space
- Route content renders via `<Outlet />`
- Lazy-loaded routes wrapped in `<Suspense>` with loading fallback

## Error Boundary Pattern

Error page for uncaught errors:
- Background: lilac-80
- Centered content card with error illustration
- "Try again" button → reloads the page
- "Contact support" button → links to support

## Route Lazy Loading

All route components should be lazy-loaded:
```tsx
const DashboardPage = lazy(() => import('./pages/Dashboard'));

// In router config:
{ path: '/dashboard', element: <DashboardPage /> }
```

Wrapped by the Suspense in AuthenticatedLayout.

## Form System

### Form Component Hierarchy

```
Form (FormProvider from react-hook-form)
  └── FormField (Controller wrapper with name context)
        └── FormItem (flex column container with id context)
              ├── FormLabel (linked to field via htmlFor)
              ├── FormControl (Slot with aria bindings)
              │     └── <Input /> / <Combobox /> / etc.
              ├── FormDescription (optional helper text)
              └── FormMessage (error display)
```

### Core Form Components

```tsx
// Form = FormProvider (re-export from react-hook-form)

// FormField — wraps Controller, provides name context
const FormField = <TFieldValues, TName>({ ...props }: ControllerProps) => (
  <FormFieldContext.Provider value={{ name: props.name }}>
    <Controller {...props} />
  </FormFieldContext.Provider>
);

// FormItem — flex column container, generates unique id
const FormItem = forwardRef(({ className, ...props }, ref) => {
  const id = useId();
  return (
    <FormItemContext.Provider value={{ id }}>
      <div ref={ref} className={classNames('flex w-full flex-col gap-2', className)} {...props} />
    </FormItemContext.Provider>
  );
});

// FormLabel — linked to field via formItemId
const FormLabel = forwardRef(({ className, ...props }, ref) => {
  const { formItemId } = useFormField();
  return <Label ref={ref} className={classNames(className)} htmlFor={formItemId} {...props} />;
});

// FormControl — Slot that injects aria attributes
const FormControl = forwardRef(({ ...props }, ref) => {
  const { error, formItemId, formDescriptionId, formMessageId } = useFormField();
  return (
    <Slot
      ref={ref}
      id={formItemId}
      aria-describedby={!error ? formDescriptionId : `${formDescriptionId} ${formMessageId}`}
      aria-invalid={!!error}
      {...props}
    />
  );
});

// FormDescription — helper text below field
const FormDescription = forwardRef(({ className, ...props }, ref) => {
  const { formDescriptionId } = useFormField();
  return <p ref={ref} id={formDescriptionId} className={classNames('text-sm text-sfgray-100', className)} {...props} />;
});

// FormMessage — error text, conditionally rendered
const FormMessage = forwardRef(({ className, children, ...props }, ref) => {
  const { error, formMessageId } = useFormField();
  const body = error ? String(error?.message) : children;
  if (!body) return null;
  return (
    <p ref={ref} id={formMessageId}
      className={classNames('text-sm font-normal', { 'text-dang-80': error }, className)}
      {...props}
    >{body}</p>
  );
});
```

### useFormField Hook

Bridges FormField context, FormItem context, and react-hook-form's field state:

```tsx
const useFormField = () => {
  const fieldContext = useContext(FormFieldContext);
  const itemContext = useContext(FormItemContext);
  const { getFieldState, formState } = useFormContext();
  const fieldState = getFieldState(fieldContext.name, formState);
  const { id } = itemContext;

  return {
    id,
    name: fieldContext.name,
    formItemId: `${id}-form-item`,
    formDescriptionId: `${id}-form-item-description`,
    formMessageId: `${id}-form-item-message`,
    ...fieldState,
  };
};
```

### Zod Schema Pattern

Define inline with translated error messages:
```tsx
const schema = z.object({
  name: z.string().min(1, t('validation.required', 'This field is required')),
  email: z.string().email(t('validation.email', 'Invalid email address')),
  description: z.string().max(500).optional(),
});

type FormData = z.infer<typeof schema>;
```

### Standard Form Layout

```tsx
<Form {...form}>
  <form onSubmit={form.handleSubmit(onSubmit)} className="flex w-[35rem] max-w-full flex-col gap-8">
    <h2 className="text-xl font-bold">Form Title</h2>

    <FormField
      control={form.control}
      name="name"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Name *</FormLabel>
          <FormControl>
            <Input {...field} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />

    <FormField
      control={form.control}
      name="description"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Description</FormLabel>
          <FormControl>
            <Textarea {...field} maxLength={500} />
          </FormControl>
          <FormDescription>Optional description</FormDescription>
          <FormMessage />
        </FormItem>
      )}
    />

    <div className="flex items-center justify-end gap-3">
      <Button variant="outline" onClick={onCancel}>Cancel</Button>
      <Button variant="primary" type="submit">Save</Button>
    </div>
  </form>
</Form>
```

### Form Conventions

| Convention | Detail |
|-----------|--------|
| Container width | `w-[35rem] max-w-full` |
| Field spacing | `gap-8` between fields |
| Label-to-field gap | `gap-2` (via FormItem) |
| Required indicator | Append ` *` to label text |
| Cancel button | `variant="outline"` |
| Submit button | `variant="primary"`, always last |
| Button alignment | `flex items-center justify-end gap-3` |
| Error text | `text-sm text-dang-80`, auto-linked via `aria-describedby` |
| Description text | `text-sm text-sfgray-100` |
| Validation mode | Typically `onBlur` for best UX |
| Submit prevention | Button `type="button"` default prevents accidental submission |

### Form Setup with React Hook Form + Zod

```tsx
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const schema = z.object({ /* ... */ });

function MyForm() {
  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    mode: 'onBlur',
    defaultValues: { /* ... */ },
  });

  const onSubmit = async (data: z.infer<typeof schema>) => {
    await mutation.mutateAsync(data);
    toast.success('Saved successfully');
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        {/* FormField components */}
      </form>
    </Form>
  );
}
```

### Server State Integration

Forms that create/update data should use `@tanstack/react-query` mutations:

```tsx
const mutation = useMutation({
  mutationFn: (data: FormData) => api.post('/endpoint', data),
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['resource'] });
    toast.success('Created successfully');
    navigate('/resource');
  },
  onError: () => {
    toast.error('Something went wrong');
  },
});
```

Every mutation must trigger a toast (success or error) as per the design system rules.
