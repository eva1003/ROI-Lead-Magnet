# Component Blueprints

Buildable blueprints for every core component. Each shows the CVA variants, props interface, and implementation pattern using Radix UI + CVA + Tailwind.

All components follow the pattern from SKILL.md §4: CVA variants → forwardRef → Slot/asChild → classNames merge.

## Button

Full implementation in SKILL.md §4. Summary of variants:

**Sizes:** `sm` (h-7), `md` (h-11), `icon-sm` (size-7), `icon-normal` (size-8), `icon-md` (size-11), `icon-rounded` (size-10 rounded-full)

**Variants:**
| Variant | Key classes |
|---------|-----------|
| `primary` | `border-primary bg-primary text-darkgreen-100` |
| `secondary` | `border-sfgray-40 bg-sfgray-10` |
| `outline` | `border-darkgreen-100 bg-transparent` |
| `outlineWhite` | `border-white bg-transparent text-white` |
| `ghost` | `border-transparent bg-transparent hover:bg-sfgray-20` |
| `danger` | `border-dang-80 bg-dang-80 text-white` |
| `link` | `underline underline-offset-2 border-none font-normal` |
| `transparent` | `border-none bg-transparent hover:opacity-50` |
| `ai` | Gradient `from-lilac-80 to-sfpurple-100`, animated on hover |
| `chat` | `bg-an-40 text-white rounded h-10 w-10` |
| `pinkHover` | `bg-white hover:bg-lilac-20 border-none` |
| `darkGreen` | `bg-darkgreen-100 text-white hover:bg-darkgreen-80` |

**Hover default:** `hover:border-morningsun-100 hover:bg-morningsun-100`
**Disabled:** `disabled:cursor-not-allowed disabled:border-sfgray-20 disabled:text-sfgray-100`
**Focus:** `focus-visible:ring focus-visible:ring-lilac-40`

Supports `asChild` via Radix Slot. Default `type="button"` to prevent form submission.

## Card

```tsx
const cardVariants = cva(
  'relative p-6 text-left rounded-md border border-sfgray-20',
  {
    variants: {
      variant: {
        default: 'bg-white',
        transparent: 'bg-transparent border-darkgreen-100 border-dashed',
      },
    },
    defaultVariants: { variant: 'default' },
  },
);
```

**Sub-components:**
- `CardMainActionSlot` — wraps a `<Link>` to make the entire card clickable via `before:absolute before:inset-0`. Uses `focus-visible:ring focus-visible:ring-lilac-60`.
- `CardActionSlot` — `relative z-10`, positions buttons on top of the main action link.

```tsx
<Card>
  <CardMainActionSlot><Link to="/detail">View</Link></CardMainActionSlot>
  <h3>Title</h3>
  <CardActionSlot><Button size="icon-sm">...</Button></CardActionSlot>
</Card>
```

## Badge

```tsx
const badgeVariants = cva('inline-flex items-center rounded h-7 px-2 text-sm font-bold gap-2', {
  variants: {
    variant: {
      pink: 'bg-pink-10 text-primary',
      pinkInverted: 'bg-pink-100 text-pink-10',
      green: 'bg-green-10 text-green-100',
      greenInverted: 'bg-green-100 text-green-10',
      sfblue: 'bg-sfblue-10 text-sfblue-100',
      sforange: 'bg-sforange-10 text-sforange-100',
      sforangeInverted: 'bg-sforange-100 text-sforange-10',
      sfgreen: 'bg-sfgreen-10 text-sfgreen-100',
      sfgray: 'bg-sfgray-10 text-sfgray-100',
      sfpurple: 'bg-sfpurple-10 text-sfpurple-100',
      lime: 'bg-lime-40 text-green-100',
      warn: 'bg-warn-60 text-warn-100',
      dang: 'bg-dang-60 text-dang-80',
      darkgreen: 'text-darkgreen-75 bg-gray-20',
    },
  },
  defaultVariants: { variant: 'sfgray' },
});

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={classNames(badgeVariants({ variant }), className)} {...props} />;
}
```

## Input

Exports `inputVariants` for reuse by Textarea.

```tsx
const inputVariants = cva(
  [
    'w-full h-11 rounded-md border border-solid px-4 py-3 text-md outline-none transition-colors',
    'hover:border-primary',
    'disabled:placeholder:text-sfgray-100 disabled:bg-sfgray-10 disabled:text-sfgray-100 disabled:hover:border-sfgray-20 disabled:cursor-not-allowed',
    'focus-visible:border-primary focus-visible:ring focus-visible:ring-lilac-60',
    'invalid:border-dang-80 invalid:hover:border-dang-80 invalid:focus-visible:border-dang-80 invalid:focus-visible:ring invalid:focus-visible:ring-dang-60',
    'border-sfgray-20 text-darkgreen-100 placeholder:text-an-40',
  ],
);
```

**Icon support:** Wrap in `relative flex w-full items-center`. Icon positioned `absolute left-4` or `right-4`. Input gets `pl-11` or `pr-11` when icon is present.

**Props:** `icon?: ReactNode`, `iconSlot?: 'start' | 'end'`, `asChild?: boolean`

## Textarea

Reuses `inputVariants` from Input. Adds `h-auto` class. Character counter shown when `maxLength` is provided:

```tsx
const Textarea = forwardRef<HTMLTextAreaElement, Props>(
  ({ className, maxLength, value, ...rest }, ref) => (
    <div className="flex w-full flex-col gap-1">
      <textarea
        className={classNames(inputVariants(), 'h-auto', className)}
        ref={ref}
        value={value ?? ''}
        maxLength={maxLength}
        {...rest}
      />
      {maxLength && (
        <p className="ml-auto text-sm text-sfgray-100">
          {value?.toString().length ?? 0} / {maxLength} characters
        </p>
      )}
    </div>
  ),
);
```

## Checkbox

Radix `@radix-ui/react-checkbox`. Two variants, two sizes.

```tsx
const checkboxVariants = cva(
  [
    'group peer flex shrink-0 cursor-pointer items-center justify-center rounded border border-solid border-sfgray-40 bg-transparent outline-none transition-colors',
    'focus-visible:ring',
    'disabled:cursor-not-allowed disabled:border-none disabled:bg-sfgray-20',
    'invalid:border-dang-80',
  ],
  {
    variants: {
      variant: {
        primary: 'hover:border-primary focus-visible:ring-pink-60 data-[state=checked]:bg-primary data-[state=checked]:border-primary data-[state=indeterminate]:bg-primary',
        outline: 'border-an-100 focus-visible:ring-an-60 data-[state=checked]:border-darkgreen-100 data-[state=checked]:bg-transparent',
      },
      size: {
        sm: 'size-5',
        lg: 'size-7',
      },
    },
    defaultVariants: { variant: 'primary', size: 'lg' },
  },
);
```

**Indicator icons:** Check icon for `data-[state=checked]`, Minus icon for `data-[state=indeterminate]`. Uses context-based `CheckboxLabel` linked via `htmlFor`.

## RadioGroup

Radix `@radix-ui/react-radio-group`.

```tsx
function RadioGroup({ className, ...props }) {
  return <RadioGroupPrimitive.Root className={classNames('grid gap-3', className)} {...props} />;
}

function RadioGroupItem({ className, ...props }) {
  return (
    <RadioGroupPrimitive.Item
      className={classNames(
        'size-4 rounded-full border text-primary outline-none focus-visible:ring-[3px] focus-visible:ring-pink-60 data-[state=checked]:bg-primary disabled:cursor-not-allowed disabled:opacity-50',
        className,
      )}
      {...props}
    >
      <RadioGroupPrimitive.Indicator className="flex h-full w-full items-center justify-center">
        <div className="size-2 rounded-full bg-an-100" />
      </RadioGroupPrimitive.Indicator>
    </RadioGroupPrimitive.Item>
  );
}
```

## Combobox

Complex component built from Radix Popover + cmdk. Supports single select, multi-select, radio mode, search, groups, and custom triggers.

**Architecture:** `Combobox` (context provider + Popover.Root) → `ComboboxTrigger` (Popover.Trigger) → `ComboboxContent` (Popover.Content + Command) → `ComboboxList` (Command.List) → `ComboboxItem` (Command.Item).

**Key sub-components:**
- `ComboboxTrigger` — CVA variants for size (`sm`: h-7, `md`: h-11) and state (`none`, `error`, `warning`, `success`). Focus ring: `focus-visible:ring-lilac-60`.
- `ComboboxContent` — Animated via `tailwindcss-animate` classes: `animate-in/animate-out`, `fade-in-0/fade-out-0`, `zoom-in-95/zoom-out-95`, `slide-in-from-*-2`. Styled: `rounded-md border border-sfgray-20 bg-white shadow-xl`.
- `ComboboxInput` — Search bar with icon: `flex items-center border-b border-sfgray-20 py-2.5 pl-4 pr-2`.
- `ComboboxItem` — `min-h-9 rounded-md px-2 py-1.5 text-sm hover:bg-sfgray-10`. Multi-select shows checkbox; single shows check icon on `aria-current=true`.
- `ComboboxValue` — Displays selected value in trigger. Multi-select shows first value + "+N" badge.
- `ComboboxGroup` — Groups items with bold heading.
- `ComboboxIcon` — Chevron that rotates 180° when open via `group-data-[state=open]:rotate-180`.
- `ComboboxReset` — Small X button to clear selection.

```tsx
<Combobox value={value} onValueChange={setValue}>
  <ComboboxTrigger size="md">
    <ComboboxValue placeholder="Select..." />
    <ComboboxIcon />
  </ComboboxTrigger>
  <ComboboxContent>
    <ComboboxInput placeholder="Search..." />
    <ComboboxList>
      <ComboboxEmpty>No results</ComboboxEmpty>
      <ComboboxItem value="a"><ComboboxTextValue>Option A</ComboboxTextValue></ComboboxItem>
      <ComboboxItem value="b"><ComboboxTextValue>Option B</ComboboxTextValue></ComboboxItem>
    </ComboboxList>
  </ComboboxContent>
</Combobox>
```

## Tabs

Radix `@radix-ui/react-tabs`. Two visual variants.

```tsx
const tabTriggerVariants = cva('', {
  variants: {
    variant: {
      primary: '-mx-2 inline-flex h-7 text-md items-center justify-center px-2 font-bold underline decoration-transparent decoration-2 underline-offset-[6px] transition-all hover:decoration-lilac-20 focus-visible:ring focus-visible:ring-lilac-60 data-[state=active]:decoration-primary',
      secondary: 'rounded-md px-5 py-3 border border-sfgray-20 font-normal hover:bg-morningsun-100 hover:border-morningsun-100 data-[state=active]:border-lilac-60 data-[state=active]:bg-lilac-20',
    },
  },
  defaultVariants: { variant: 'primary' },
});
```

- `TabsList`: `inline-flex items-center justify-center gap-6`
- `TabsContent`: `mt-6` with `tabIndex={-1}`
- Supports `unstyled` prop to bypass all styling.

## Accordion

Radix `@radix-ui/react-accordion`.

```tsx
// AccordionItem: border-b border-sfgray-40
// AccordionTrigger: w-full rounded-md px-1 py-4 font-bold, with chevron that rotates on open:
//   group-data-[state=open]:rotate-180 transition-transform duration-200
// AccordionContent: overflow-hidden px-1, inner padding pb-6 pt-0
```

**Important:** Use `forceMount` prop when accordion contains form fields that must stay in the DOM when closed. Add `data-[state=closed]:hidden` to hide content visually while keeping it mounted.

## Tooltip

Radix `@radix-ui/react-tooltip` + tailwindcss-animate.

```tsx
// TooltipProvider: delayDuration={250}
// TooltipContent:
//   z-[200] rounded bg-an-100 px-4 py-1.5 text-sm text-white shadow-xl
//   animate-in fade-in-0 zoom-in-95
//   data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95
//   data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2
//   data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2
// sideOffset={4}
```

Dark background with white text. Portal-based.

## Popover

Radix `@radix-ui/react-popover` + tailwindcss-animate.

```tsx
// PopoverContent:
//   z-50 min-h-fit min-w-56 rounded-md border border-solid border-sfgray-20 bg-white p-2 text-md shadow-xl
//   Same animate-in/animate-out/slide transitions as Tooltip
// sideOffset={5}, isAnimated prop to disable animations
// Always wrapped in Portal
```

## DropdownMenu

Radix `@radix-ui/react-dropdown-menu` + tailwindcss-animate.

```tsx
// DropdownMenuContent:
//   z-[200] min-h-fit min-w-56 rounded-md border border-solid border-sfgray-20 bg-white p-2 text-md shadow-xl
//   Same animate-in/animate-out transitions
// DropdownMenuItem:
//   min-h-9 w-full rounded-md px-2 py-1.5 text-sm outline-none focus:bg-sfgray-10
//   data-[disabled]:pointer-events-none data-[disabled]:opacity-50
//   [&_svg]:text-sfgray-80
// DropdownMenuLabel: px-2 py-1.5 text-sm font-bold text-sfgray-80
// DropdownMenuSeparator: my-2 h-px bg-sfgray-20
```

## ToggleSwitch

Radix `@radix-ui/react-switch`. Context-based for id sharing.

```tsx
// Root: rounded-full bg-sfgray-40/50 transition-colors
//   data-[state=checked]:bg-primary data-[state=unchecked]:hover:bg-lilac-40
//   disabled:cursor-not-allowed disabled:bg-sfgray-40/25
//   Sizes: sm (h-5 w-10), lg (h-7 w-14)
// Thumb: rounded-full bg-white transition-transform translate-x-0.5
//   sm: h-4 w-4, data-[state=checked]:translate-x-5
//   lg: h-6 w-6, data-[state=checked]:translate-x-7
```

Composed with `ToggleSwitchLabel` linked via context id:
```tsx
<ToggleSwitch size="lg" checked={value} onCheckedChange={setValue}>
  <ToggleSwitchLabel>Enable feature</ToggleSwitchLabel>
</ToggleSwitch>
```

## Avatar

Radix `@radix-ui/react-avatar`. Initials fallback.

```tsx
const avatarVariants = cva(
  'aspect-square shrink-0 flex items-center justify-center font-bold object-contain',
  {
    variants: {
      size: {
        xs: 'h-[1.375rem] w-[1.375rem] text-xs',
        sm: 'h-[2.0625rem] w-[2.0625rem] text-sm',
        md: 'h-[3.25rem] w-[3.25rem] text-md',
        lg: 'h-[5.125rem] w-[5.125rem] text-lg',
      },
      type: {
        round: 'rounded-full',
        square: 'rounded-md',
      },
    },
  },
);
```

Fallback shows initials (`firstName[0] + lastName[0]`) with `bg-sfgray-20 text-sfgray-80`. Optional camera icon overlay on hover when `onClick` is provided.

## Spinner

CSS-only spinner using `animate-spinner` keyframe. 4 sizes, 9 colors.

```tsx
// Structure: relative container with 4 overlapping divs (1 background ring + 3 rotating arcs)
// Background ring: borderLight variants (e.g., border-sfblue-20)
// Rotating arcs: borderSolid variants (e.g., border-t-sfblue-100) with transparent right/bottom/left
// Staggered delays: 0, 150ms, 300ms
// Sizes: xs (w-5 h-5, border-[3px]), sm (w-8 h-8, border-4), md (w-12 h-12, border-[5px]), lg (w-16 h-16, border-[6px])
// Colors: blue, orange, green, gray, pink, lime, white, black, lilac
```

## ProgressBar

Radix `@radix-ui/react-progress`.

```tsx
// Root: overflow-hidden rounded-full, configurable height (default 6px), configurable backgroundColor (default bg-sfgray-20)
// Indicator: rounded-[30px], configurable barColor (default bg-sfgreen-100)
//   Animates via transform: translateX(-{100 - progress}%)
//   Transition: duration-[660ms] ease-[cubic-bezier(0.65, 0, 0.35, 1)]
// Optional showValue: "current / max" text right-aligned
// Optional animate: fills in from 0 after 500ms delay
```

## Modal

Portal-based into `#modal` div. Two backdrop variants.

```tsx
// Backdrop: fixed inset-0 z-50 overflow-auto
//   Default: bg-[rgba(197,195,193,0.6)] backdrop-blur-sm
//   New design: bg-[rgba(232,233,237,0.8)] backdrop-blur-[5px]
// Content: fixed left-1/2 top-1/2 z-[200] -translate-x-1/2 -translate-y-1/2
//   max-h-[calc(100vh-2rem)] max-w-[calc(100vw-2rem)] overflow-auto bg-white
//   Default: rounded-lg
//   New design: rounded-md border border-sfgray-20
// Escape key closes via keydown listener
// Props: setIsOpen, onClose, header, variant ('default' | 'newDesign')
```

## ModalConfirm

Extends Modal with confirmation dialog pattern:

```tsx
// Layout: px-14 pb-8 pt-16
//   Header (title + close button)
//   Content text (text-an-60)
//   Optional "don't show again" checkbox (persisted to localStorage)
//   Button row: flex items-center justify-end gap-3
//     Cancel: variant="outline"
//     Confirm: configurable variant (default "primary")
// Wraps in LoadingOverlay during async onConfirm
// If dontShowAgainKey is set AND user previously checked it, auto-confirms and renders null
```

## ModalConfirmDelete

Simplified delete confirmation:

```tsx
// Layout: px-8 pb-8 pt-16
//   Header with close button
//   Description text (text-sfgray-100)
//   Button row: Cancel (outline) + Confirm (primary, "Yes, delete")
// Props: onConfirm, onCancel, onClose, optional title/text overrides
```

## Notification

5 inline notification variants using CVA + context for icons.

```tsx
const notificationVariants = cva('py-3 px-6', {
  variants: {
    variant: {
      default: 'bg-white',
      success: 'bg-succ-60',
      warning: 'bg-warn-60',
      error: 'bg-dang-60',
      info: 'bg-sfblue-10',
    },
  },
});
// Container: flex w-80 gap-4 rounded-xl text-an-100
// NotificationIcon: context-aware, min-w-6 min-h-6, colored per variant
// NotificationTitle: text-lg font-bold
// NotificationText: text-md
// Shortcuts: NotificationError, NotificationInfo, NotificationWarning
```

## Toaster

Sonner configuration:

```tsx
<Sonner
  theme="light"
  position="top-center"
  offset={32}
  gap={8}
  icons={{ error: <span />, success: <span />, warning: <span />, info: <span />, loading: <span /> }}
  toastOptions={{
    classNames: {
      toast: 'group-[.toaster]:bg-white group-[.toaster]:text-an-100 group-[.toaster]:border-sfgray-20 group-[.toaster]:shadow-xl',
      error: 'group-[.toaster]:!bg-dang-60 group-[.toaster]:!text-dang-100',
      success: 'group-[.toaster]:!bg-succ-60 group-[.toaster]:!text-succ-100',
      warning: 'group-[.toaster]:!bg-warn-60 group-[.toaster]:!text-warn-100',
      icon: 'hidden',
    },
  }}
/>
```

Icons replaced with empty `<span />` to use color-coded backgrounds instead.

## EmptyOverlay

```tsx
// Container: z-10 h-fit w-full rounded-lg px-5 py-12 text-center
//   Optional overlay mode: absolute inset-0
//   Configurable bgColor (default bg-white)
// Content:
//   Optional Badge (sfgreen or sfblue variant)
//   Headline: text-5xl font-bold
//   Subline: text-xl
// Optional CTA: Button with Link, centered (mx-auto w-fit)
```

## LoadingOverlay

```tsx
// Wrapper: relative
// Content: transition-opacity duration-200, opacity-20 when loading
// Spinner: absolute inset-0 flex items-center justify-center
// Props: isLoading: boolean, className, children
```

## Table

Custom styled primitives for use with `@tanstack/react-table` v8.

```tsx
// Table: w-full text-left
// TableHeader/TableHeaderRow: border-b border-solid border-sfgray-40 font-bold
// TableHeaderCell: pb-6 text-sfgray-100, shared cell classes (whitespace-nowrap px-3 first:pl-0 last:pr-3)
// TableBody/TableRow: unstyled wrappers
// TableDataCell: max-w-0 py-3 text-lg, first/last rounded corners (rounded-tl-md, rounded-tr-md etc.)
// TableSortingIcon: asc/desc via -scale-y-100, active state via text-primary
// TableLoader: centered Spinner in min-h-96 container
// TableEmpty: centered text-sfgray-60 in min-h-96 container
```
