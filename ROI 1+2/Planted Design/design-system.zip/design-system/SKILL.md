---
name: design-system
description: Portable design system specification for building UIs that match the Impact-OS visual identity. Use when creating new components, pages, forms, or any visual elements in a project that should follow this design system. Covers the full stack - Tailwind CSS + Radix UI + CVA + React Hook Form + Zod. Triggers on frontend work, component creation, styling decisions, page layouts, and form building.
---

# Design System Specification

A portable guide for building UIs that replicate the Impact-OS visual identity. This skill assumes you have access to the Tailwind config file and Saans font files, but nothing else — all components are built from scratch.

## 1. Design Philosophy

- **Modern B2B with warmth** — corporate and professional, but approachable; not cold or clinical
- **Visual hierarchy through size, weight, and spacing** — guide the eye with typographic contrast and generous gaps, not decorative elements
- **White space over borders** — separate content blocks with spacing (`gap-6`, `gap-8`, `gap-12`), not boxes or dividers. Cards have borders, but within a card or section, spacing alone creates structure
- **High-contrast navigation** — dark sidebar (`bg-darkgreen-100`) against white/light content area creates the primary structural contrast
- **Color restraint** — the default UI is neutral (white, grays, black text). Brand colors (`primary`, `secondary`) and semantic colors appear only for specific purposes: actions, status, focus, emphasis. Never decorative
- **Graphical data presentation** — prefer charts (Recharts) over raw numbers for displaying metrics and trends. Tables are for detailed row-level data
- **Icons for usability, used sparingly** — icons improve scannability but are kept minimal to maintain the clean, minimalist aesthetic
- Desktop-first (min-width 900px) — not a mobile app
- Consistent semantic color usage (success=green, warning=yellow, danger=red)
- CSS-only animations — no JS animation libraries (no framer-motion)
- Class-based dark mode via `dark:` Tailwind variant

## 2. Required Tech Stack

| Category | Package |
|----------|---------|
| UI Framework | React 18 |
| Styling | Tailwind CSS 3.4, `tailwindcss-animate` |
| Primitives | Radix UI (`@radix-ui/react-*`) |
| Variant management | `class-variance-authority` (CVA) |
| Class composition | `clsx` + `tailwind-merge` |
| Forms | `react-hook-form` + `zod` + `@hookform/resolvers` |
| Server state | `@tanstack/react-query` v5 |
| Tables | `@tanstack/react-table` v8 |
| Charts | `recharts` |
| Toasts | `sonner` |
| Command palette | `cmdk` |
| Icons | `lucide-react` (supplement with custom SVGs) |

## 3. The `classNames()` Utility

This is foundational — create it first, use it everywhere. Never concatenate className strings manually.

```ts
import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function classNames(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

Usage: `classNames('base-classes', conditionalObj, className)` — always merge the consumer's `className` last.

## 4. Component Architecture Pattern

Every component follows this pattern: CVA variants → forwardRef → Slot support → classNames merge.

### Canonical Example: Button

```tsx
import { Slot } from '@radix-ui/react-slot';
import { cva, VariantProps } from 'class-variance-authority';
import { ButtonHTMLAttributes, forwardRef } from 'react';
import { classNames } from '@/utils/classNames';

const variants = cva(
  // Base classes shared by all variants
  'group/button flex cursor-pointer items-center justify-center gap-4 whitespace-nowrap border font-bold outline-none transition-colors focus-visible:ring focus-visible:ring-lilac-40 disabled:cursor-not-allowed disabled:border-sfgray-20 disabled:text-sfgray-100 w-fit',
  {
    variants: {
      size: {
        sm: 'h-7 px-4 text-sm rounded-md',
        md: 'h-11 px-7 text-lg rounded-md',
        'icon-sm': 'size-7 justify-center rounded-md',
        'icon-md': 'size-11 justify-center rounded-md',
        'icon-rounded': 'size-10 justify-center rounded-full',
      },
      variant: {
        primary: 'border-primary bg-primary text-darkgreen-100 hover:border-morningsun-100 hover:bg-morningsun-100 disabled:bg-sfgray-20',
        secondary: 'border-sfgray-40 bg-sfgray-10 text-darkgreen-100 hover:border-morningsun-100 hover:bg-morningsun-100 disabled:bg-white',
        outline: 'border-darkgreen-100 bg-transparent text-darkgreen-100 disabled:bg-transparent disabled:pointer-events-none disabled:border-sfgray-20',
        ghost: 'border-transparent bg-transparent hover:bg-sfgray-20 hover:border-sfgray-20 disabled:bg-transparent disabled:border-none disabled:text-sfgray-20',
        danger: 'border-dang-80 bg-dang-80 text-white hover:border-dang-100 hover:bg-dang-100 disabled:bg-sfgray-20',
        link: 'underline underline-offset-2 text-left border-none gap-1.5 font-normal disabled:pointer-events-none disabled:opacity-50',
        darkGreen: 'bg-darkgreen-100 border-darkgreen-100 text-white hover:bg-darkgreen-80 hover:border-darkgreen-80 disabled:bg-sfgray-20',
      },
    },
    defaultVariants: { variant: 'primary', size: 'md' },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof variants> & { asChild?: boolean };

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ children, className, asChild, variant, size, disabled, type = 'button', ...props }, ref) => {
    const Comp = asChild ? Slot : 'button';
    return (
      <Comp
        className={classNames(variants({ variant, size }), className)}
        type={!asChild ? type : undefined}
        disabled={disabled}
        aria-disabled={disabled ? 'true' : undefined}
        tabIndex={disabled ? -1 : undefined}
        {...props}
        ref={ref}
      >
        {children}
      </Comp>
    );
  },
);
```

### Key Rules

1. Every component **must** accept a `className` prop and merge it last via `classNames()`
2. Use `forwardRef` for all components that render DOM elements
3. Support `asChild` via Radix `Slot` when the component wraps interactive elements
4. Disabled state: set both `disabled` and `aria-disabled="true"` for non-button elements
5. Export CVA variant definitions separately when they need to be reused (e.g. `inputVariants` shared by Input and Textarea)

## 5. Color System Overview

Full palette in `references/design-tokens.md`. Key groups:

| Group | Key tokens | Usage |
|-------|-----------|-------|
| Brand primary | `primary` (#DAC4FF lilac) | Buttons, focus rings, active states |
| Brand secondary | `secondary` (#B4FA64 lime) | Accents, highlights |
| Dark green | `darkgreen-100` (#002616) → `darkgreen-10` | Primary text, dark buttons |
| Anthracite | `an-100` (#232D32) → `an-10` | Body text, secondary text |
| Interface grays | `sfgray-100` → `sfgray-5` | Borders, backgrounds, disabled states |
| Success | `succ-60/80/100` | Success states, confirmations |
| Warning | `warn-60/80/100` | Warning states |
| Danger | `dang-60/80/100` | Error states, destructive actions |
| Feature colors | `sfblue-*`, `sforange-*`, `sfgreen-*`, `sfpurple-*` | Category differentiation |
| Accent | `lilac-*`, `morningsun-*`, `coral-*`, `pink-*`, `lime-*` | Decorative accents |
| Focus ring | `lilac-40` / `lilac-60` | All focus-visible rings |

**Usage philosophy:** The default UI is overwhelmingly neutral — `bg-white` cards on `bg-sfgray-5` backgrounds with `text-an-100` body text. Apply color with intention:
- **Brand primary/secondary** — interactive elements (buttons, focus rings, active states), never as background fills for content areas
- **Semantic (success/warning/danger)** — status indicators, form validation, toast messages only
- **Feature colors** — distinguish categories in charts and data visualizations, not for general UI decoration
- **Accent colors** — hover states, subtle highlights; used sparingly

All colors are exported as CSS variables via a Tailwind plugin (e.g., `var(--tw-color-primary)`).

## 6. Typography

**Font:** Saans (custom), 4 weights with italic variants:
- `font-normal` = 380
- `font-medium` = 500
- `font-semibold` = 670
- `font-bold` = 790

**Scale (most used):**
- Body text: `text-lg` (16px/24px) or `text-md` (14px/22px)
- Small/labels: `text-sm` (12px/18px)
- Page title: `text-xl font-bold` (20px/28px)
- Section heading: `text-3xl font-semibold` (26px/32px)
- Large display: `text-5xl font-bold` (36px/48px)

**Rules:**
- Font ligatures disabled
- Default body color: `text-an-100` (set on `<body>`)
- `font-family: ['Saans', 'sans-serif']` for both `sans` and `serif`

**Hierarchy strategy:**

Use size and weight differences to create clear reading order:

| Level | Classes | Example |
|-------|---------|---------|
| Page title | `text-xl font-bold` | Top of page, in PageHeader |
| Section heading | `text-2xl font-bold` or `text-3xl font-semibold` | Major content blocks |
| Card / subsection title | `text-lg font-bold` | Inside cards, accordion triggers |
| Body text | `text-lg` or `text-md` | Default reading content |
| Labels / captions | `text-sm`, often `text-an-60` or `text-sfgray-100` | Secondary info, metadata |

Spacing creates grouping: tight gaps (`gap-2`, `gap-3`) connect related items; medium gaps (`gap-4`, `gap-6`) separate siblings within a section; large gaps (`gap-8`, `gap-12`) separate distinct sections. When in doubt, use more space, not less.

Font face declarations — register in a CSS file:
```css
@font-face {
  font-family: 'Saans';
  src: url('./fonts/SaansRegular.otf') format('opentype');
  font-weight: 380;
  font-style: normal;
  font-display: swap;
}
/* Repeat for Regular Italic (380), Medium (500), Medium Italic, SemiBold (670), SemiBold Italic, Bold (790), Bold Italic */
```

## 7. Toast & Notification Pattern

### Toasts (transient)
Use `sonner` positioned `top-center`:
```tsx
<Sonner
  theme="light"
  position="top-center"
  offset={32}
  gap={8}
  toastOptions={{
    classNames: {
      toast: 'group-[.toaster]:bg-white group-[.toaster]:text-an-100 group-[.toaster]:border-sfgray-20 group-[.toaster]:shadow-xl',
      error: 'group-[.toaster]:!bg-dang-60 group-[.toaster]:!text-dang-100',
      success: 'group-[.toaster]:!bg-succ-60 group-[.toaster]:!text-succ-100',
      warning: 'group-[.toaster]:!bg-warn-60 group-[.toaster]:!text-warn-100',
    },
  }}
/>
```
**Rule:** Every mutation (create/update/delete) must show a success or error toast.

### Inline Notifications (persistent)
5 variants: `default`, `success`, `warning`, `error`, `info`. Each uses a context-aware icon and color-coded background. Composed as `Notification > NotificationIcon + NotificationText`.

## 8. Modal Pattern

- Portal-based: renders into a `#modal` div
- Backdrop: `fixed inset-0 z-50` with blur + configurable opacity
  - Default: `bg-[rgba(197,195,193,0.6)] backdrop-blur-sm`
  - New design: `bg-[rgba(232,233,237,0.8)] backdrop-blur-[5px]`
- Content: centered via `fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2`, `z-[200]`, `max-h-[calc(100vh-2rem)]`
- Escape key to close (event listener on mount)
- Two visual variants: `default` (rounded-lg) and `newDesign` (rounded-md + border)
- Confirmation variant: title + content + cancel (outline) / confirm buttons, optional "don't show again" checkbox with localStorage persistence

## 9. Loading & Empty States

### Spinner
CSS-only spinner using `animate-spinner` (1.2s cubic-bezier rotation). 4 sizes (`xs`/`sm`/`md`/`lg`), 9 color variants (`blue`/`orange`/`green`/`gray`/`pink`/`lime`/`white`/`black`/`lilac`). Built from overlapping `border-radius: 50%` divs with staggered delays.

### LoadingOverlay
Wraps content, dims to `opacity-20` when loading, centered Spinner on top:
```tsx
<div className="relative">
  <div className={classNames('transition-opacity duration-200', { 'opacity-20': isLoading })}>{children}</div>
  {isLoading && (
    <div className="absolute inset-0 flex items-center justify-center"><Spinner /></div>
  )}
</div>
```

### EmptyOverlay
Empty state: `rounded-lg px-5 py-12 text-center` with optional badge, headline (`text-5xl font-bold`), subline (`text-xl`), and CTA button.

## 10. Critical Rules

1. **Never hardcode hex colors** — always use Tailwind tokens from the config
2. **Always use `classNames()`** — never raw className string concatenation
3. **All interactive elements must have `focus-visible` ring** using `focus-visible:ring focus-visible:ring-lilac-40` (or `lilac-60` for inputs)
4. **Disabled states** via `aria-disabled="true"` + the custom `disabled:` Tailwind variant (matches both `:disabled` and `[aria-disabled="true"]`)
5. **Custom Tailwind variants:** `disabled`, `invalid` (matches `:invalid` and `[aria-invalid="true"]`), `only-child`
6. **Dark mode** via `dark:` variant (class-based strategy, toggled on a parent element)
7. **Border default:** `border-sfgray-20` for cards, inputs, dividers
8. **Background default:** `bg-sfgray-5` (page background), `bg-white` (cards/panels), `bg-offwhite` (#EBEBEB, authenticated layout)
9. **Minimum viewport:** `min-w-[900px]` on authenticated layout

## 11. Reference Files

Read these when you need specific implementation details:

| File | When to read |
|------|-------------|
| `references/design-tokens.md` | Need exact color hex values, font sizes, spacing, shadows, animation keyframes, or breakpoint values |
| `references/component-blueprints.md` | Building any new component — match existing API patterns and styling |
| `references/page-and-form-patterns.md` | Creating pages, layouts, authenticated routes, or forms with validation |
